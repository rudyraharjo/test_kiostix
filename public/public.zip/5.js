(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[5],{

/***/ "./resources/js/pages/menu/List.vue":
/*!******************************************!*\
  !*** ./resources/js/pages/menu/List.vue ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/vue-loader/lib/index.js):\nError: ENOENT: no such file or directory, open 'D:\\laragon\\www\\twinpasta\\resources\\js\\pages\\menu\\List.vue'");

/***/ })

}]);